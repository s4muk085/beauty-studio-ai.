// API serverless da Vercel. NUNCA coloque o token no código do navegador.
const WINDOW_MS = 60_000;
const counts = new Map(); // apenas proteção simples por instância; em produção use rate limit persistente
export default async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') return res.status(405).json({ error: 'Método não permitido' });
  const account = process.env.CLOUDFLARE_ACCOUNT_ID;
  const token = process.env.CLOUDFLARE_API_TOKEN;
  if (!account || !token) return res.status(503).json({ error: 'IA não configurada. Configure as variáveis Cloudflare na Vercel. O editor e os templates seguem funcionando.' });
  const ip = String(req.headers['x-forwarded-for'] || 'unknown').split(',')[0].trim();
  const now = Date.now();
  for (const [k,v] of counts) if (v.reset < now) counts.delete(k);
  const current = counts.get(ip) || { count: 0, reset: now + WINDOW_MS };
  if (current.count >= 3) return res.status(429).json({ error: 'Limite temporário de 3 gerações por minuto. Tente novamente em breve.' });
  current.count++; counts.set(ip, current);
  const { prompt = '', niche = '', tone = '' } = req.body || {};
  if (typeof prompt !== 'string' || prompt.trim().length < 4 || prompt.length > 600) return res.status(400).json({ error: 'Descreva a imagem entre 4 e 600 caracteres.' });
  const safeNiche = String(niche).slice(0,80); const safeTone = String(tone).slice(0,80);
  const enhanced = `Professional premium editorial beauty photography for social media of ${safeNiche}. ${prompt}. Style: ${safeTone}. Sophisticated salon aesthetic, premium studio lighting, realistic photographic detail, beautiful clean composition. Main subject in center, intentional generous negative space for graphic layout. NO TEXT, NO LETTERS, NO LOGOS, NO WATERMARKS, no words. Vertical creative background.`;
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 45000);
    const response = await fetch(`https://api.cloudflare.com/client/v4/accounts/${encodeURIComponent(account)}/ai/run/@cf/black-forest-labs/flux-1-schnell`, {
      method: 'POST', headers: { 'Authorization': `Bearer ${token}`, 'Content-Type':'application/json' },
      body: JSON.stringify({ prompt: enhanced.slice(0,2048), steps: 4 }), signal: controller.signal
    }).finally(() => clearTimeout(timeout));
    const data = await response.json().catch(() => null);
    if (!response.ok || !data?.success || !data?.result?.image) {
      const msg = response.status === 429 ? 'Cota gratuita ou limite da API atingido.' : 'Não foi possível gerar a imagem neste momento.';
      return res.status(response.status === 429 ? 429 : 502).json({ error: msg });
    }
    return res.status(200).json({ image: `data:image/jpeg;base64,${data.result.image}` });
  } catch (err) {
    return res.status(502).json({ error: err?.name === 'AbortError' ? 'A geração ultrapassou o tempo limite. Tente novamente.' : 'Falha na conexão com a IA.' });
  }
}
